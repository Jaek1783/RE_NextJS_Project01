import {Fragment} from 'react';
import {getAllEvents} from '../../api-util';
import EventList from '../../components/events/event-list';
import EventSearch from '../../components/events/event-search';
import {useRouter} from 'next/router';

function AllEventsPage(props){
    const router = useRouter();
    const { events }=props;

    console.log(props.events);

    const findEventsHandler = (year , month)=>{
        const fullPath = `/events/${year}/${month}`;
        router.push(fullPath);
    }
    return(
        <Fragment>
            <EventSearch onSearch={findEventsHandler}/>
            <EventList items={events}/>
        </Fragment >
    )
}

export async function getStaticProps(){
    const events = await getAllEvents();

    return{
        props: {
            events : events
        },
        revalidate:60
    }
}

export default AllEventsPage;