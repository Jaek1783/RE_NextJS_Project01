webpackHotUpdate_N_E("pages/events/[eventDetailPageId]",{

/***/ "./api-util.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js":
false,

/***/ "./node_modules/axios/index.js":
false,

/***/ "./node_modules/axios/lib/adapters/adapters.js":
false,

/***/ "./node_modules/axios/lib/adapters/xhr.js":
false,

/***/ "./node_modules/axios/lib/axios.js":
false,

/***/ "./node_modules/axios/lib/cancel/CancelToken.js":
false,

/***/ "./node_modules/axios/lib/cancel/CanceledError.js":
false,

/***/ "./node_modules/axios/lib/cancel/isCancel.js":
false,

/***/ "./node_modules/axios/lib/core/Axios.js":
false,

/***/ "./node_modules/axios/lib/core/AxiosError.js":
false,

/***/ "./node_modules/axios/lib/core/AxiosHeaders.js":
false,

/***/ "./node_modules/axios/lib/core/InterceptorManager.js":
false,

/***/ "./node_modules/axios/lib/core/buildFullPath.js":
false,

/***/ "./node_modules/axios/lib/core/dispatchRequest.js":
false,

/***/ "./node_modules/axios/lib/core/mergeConfig.js":
false,

/***/ "./node_modules/axios/lib/core/settle.js":
false,

/***/ "./node_modules/axios/lib/core/transformData.js":
false,

/***/ "./node_modules/axios/lib/defaults/index.js":
false,

/***/ "./node_modules/axios/lib/defaults/transitional.js":
false,

/***/ "./node_modules/axios/lib/env/data.js":
false,

/***/ "./node_modules/axios/lib/helpers/AxiosURLSearchParams.js":
false,

/***/ "./node_modules/axios/lib/helpers/HttpStatusCode.js":
false,

/***/ "./node_modules/axios/lib/helpers/bind.js":
false,

/***/ "./node_modules/axios/lib/helpers/buildURL.js":
false,

/***/ "./node_modules/axios/lib/helpers/combineURLs.js":
false,

/***/ "./node_modules/axios/lib/helpers/cookies.js":
false,

/***/ "./node_modules/axios/lib/helpers/formDataToJSON.js":
false,

/***/ "./node_modules/axios/lib/helpers/isAbsoluteURL.js":
false,

/***/ "./node_modules/axios/lib/helpers/isAxiosError.js":
false,

/***/ "./node_modules/axios/lib/helpers/isURLSameOrigin.js":
false,

/***/ "./node_modules/axios/lib/helpers/null.js":
false,

/***/ "./node_modules/axios/lib/helpers/parseHeaders.js":
false,

/***/ "./node_modules/axios/lib/helpers/parseProtocol.js":
false,

/***/ "./node_modules/axios/lib/helpers/speedometer.js":
false,

/***/ "./node_modules/axios/lib/helpers/spread.js":
false,

/***/ "./node_modules/axios/lib/helpers/toFormData.js":
false,

/***/ "./node_modules/axios/lib/helpers/toURLEncodedForm.js":
false,

/***/ "./node_modules/axios/lib/helpers/validator.js":
false,

/***/ "./node_modules/axios/lib/platform/browser/classes/Blob.js":
false,

/***/ "./node_modules/axios/lib/platform/browser/classes/FormData.js":
false,

/***/ "./node_modules/axios/lib/platform/browser/classes/URLSearchParams.js":
false,

/***/ "./node_modules/axios/lib/platform/browser/index.js":
false,

/***/ "./node_modules/axios/lib/platform/index.js":
false,

/***/ "./node_modules/axios/lib/utils.js":
false,

/***/ "./node_modules/base64-js/index.js":
false,

/***/ "./node_modules/ieee754/index.js":
false,

/***/ "./node_modules/isarray/index.js":
false,

/***/ "./node_modules/next/dist/compiled/webpack/global.js":
false,

/***/ "./node_modules/node-libs-browser/node_modules/buffer/index.js":
false,

/***/ "./pages/events/[eventDetailPageId].js":
/*!*********************************************!*\
  !*** ./pages/events/[eventDetailPageId].js ***!
  \*********************************************/
/*! exports provided: __N_SSG, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"__N_SSG\", function() { return __N_SSG; });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"./node_modules/react/jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"./node_modules/react/index.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _components_event_detail_event_summary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/event-detail/event-summary */ \"./components/event-detail/event-summary.js\");\n/* harmony import */ var _components_event_detail_event_logistics__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/event-detail/event-logistics */ \"./components/event-detail/event-logistics.js\");\n/* harmony import */ var _components_event_detail_event_content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/event-detail/event-content */ \"./components/event-detail/event-content.js\");\n\n\nvar _jsxFileName = \"/Users/jk_mac/Desktop/\\u110B\\u1170\\u11B8\\u1100\\u1162\\u1107\\u1161\\u11AF/\\u1102\\u1166\\u11A8\\u1109\\u1173\\u1110\\u1173JS/\\u1111\\u1173\\u1105\\u1169\\u110C\\u1166\\u11A8\\u1110\\u1173 \\u1109\\u1175\\u11AF\\u1109\\u1173\\u11B8/eventPage02/pages/events/[eventDetailPageId].js\",\n    _s = $RefreshSig$();\n\n // import { getEventById } from '../../dummy-data';\n\n\n\n\n\n\nfunction EventDetailPage(props) {\n  _s();\n\n  //경로 세그먼트 데이터 추출\n  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_1__[\"useRouter\"])();\n  var event = props.selectedEvent;\n  console.log(event); //만약 수기로 경로를 입력했을 때 데이터가 없는 경우\n\n  if (!event) {\n    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(\"div\", {\n      children: \"Sorry No Data\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 18,\n      columnNumber: 13\n    }, this);\n  }\n\n  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(react__WEBPACK_IMPORTED_MODULE_2__[\"Fragment\"], {\n    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_components_event_detail_event_summary__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n      title: event.title\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 23,\n      columnNumber: 13\n    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_components_event_detail_event_logistics__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {\n      date: event.date,\n      address: event.location,\n      image: event.image,\n      imageAlt: event.title\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 24,\n      columnNumber: 13\n    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_components_event_detail_event_content__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {\n      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(\"p\", {\n        children: event.description\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 31,\n        columnNumber: 17\n      }, this)\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 30,\n      columnNumber: 13\n    }, this)]\n  }, void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 22,\n    columnNumber: 9\n  }, this);\n}\n\n_s(EventDetailPage, \"fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=\", false, function () {\n  return [next_router__WEBPACK_IMPORTED_MODULE_1__[\"useRouter\"]];\n});\n\n_c = EventDetailPage;\nvar __N_SSG = true;\n/* harmony default export */ __webpack_exports__[\"default\"] = (EventDetailPage);\n\nvar _c;\n\n$RefreshReg$(_c, \"EventDetailPage\");\n\n;\n    var _a, _b;\n    // Legacy CSS implementations will `eval` browser code in a Node.js context\n    // to extract CSS. For backwards compatibility, we need to check we're in a\n    // browser context before continuing.\n    if (typeof self !== 'undefined' &&\n        // AMP / No-JS mode does not inject these helpers:\n        '$RefreshHelpers$' in self) {\n        var currentExports = module.__proto__.exports;\n        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;\n        // This cannot happen in MainTemplate because the exports mismatch between\n        // templating and execution.\n        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);\n        // A module can be accepted automatically based on its exports, e.g. when\n        // it is a Refresh Boundary.\n        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {\n            // Save the previous exports on update so we can compare the boundary\n            // signatures.\n            module.hot.dispose(function (data) {\n                data.prevExports = currentExports;\n            });\n            // Unconditionally accept an update to this module, we'll check if it's\n            // still a Refresh Boundary later.\n            module.hot.accept();\n            // This field is set when the previous version of this module was a\n            // Refresh Boundary, letting us know we need to check for invalidation or\n            // enqueue an update.\n            if (prevExports !== null) {\n                // A boundary can become ineligible if its exports are incompatible\n                // with the previous exports.\n                //\n                // For example, if you add/remove/change exports, we'll want to\n                // re-execute the importing modules, and force those components to\n                // re-render. Similarly, if you convert a class component to a\n                // function, we want to invalidate the boundary.\n                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {\n                    module.hot.invalidate();\n                }\n                else {\n                    self.$RefreshHelpers$.scheduleUpdate();\n                }\n            }\n        }\n        else {\n            // Since we just executed the code for the module, it's possible that the\n            // new exports made it ineligible for being a boundary.\n            // We only care about the case when we were _previously_ a boundary,\n            // because we already accepted this update (accidental side effect).\n            var isNoLongerABoundary = prevExports !== null;\n            if (isNoLongerABoundary) {\n                module.hot.invalidate();\n            }\n        }\n    }\n\n/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ \"./node_modules/next/dist/compiled/webpack/harmony-module.js\")(module)))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvZXZlbnRzL1tldmVudERldGFpbFBhZ2VJZF0uanM/MmVmMCJdLCJuYW1lcyI6WyJFdmVudERldGFpbFBhZ2UiLCJwcm9wcyIsInJvdXRlciIsInVzZVJvdXRlciIsImV2ZW50Iiwic2VsZWN0ZWRFdmVudCIsImNvbnNvbGUiLCJsb2ciLCJ0aXRsZSIsImRhdGUiLCJsb2NhdGlvbiIsImltYWdlIiwiZGVzY3JpcHRpb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FDQTs7QUFFQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQSxTQUFTQSxlQUFULENBQXlCQyxLQUF6QixFQUErQjtBQUFBOztBQUMzQjtBQUNBLE1BQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFDQSxNQUFNQyxLQUFLLEdBQUdILEtBQUssQ0FBQ0ksYUFBcEI7QUFDQUMsU0FBTyxDQUFDQyxHQUFSLENBQVlILEtBQVosRUFKMkIsQ0FNM0I7O0FBQ0EsTUFBRyxDQUFDQSxLQUFKLEVBQVU7QUFDTix3QkFDSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKO0FBR0g7O0FBQ0Qsc0JBQ0kscUVBQUMsOENBQUQ7QUFBQSw0QkFDSSxxRUFBQyw4RUFBRDtBQUFjLFdBQUssRUFBRUEsS0FBSyxDQUFDSTtBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREosZUFFSSxxRUFBQyxnRkFBRDtBQUNJLFVBQUksRUFBRUosS0FBSyxDQUFDSyxJQURoQjtBQUVJLGFBQU8sRUFBRUwsS0FBSyxDQUFDTSxRQUZuQjtBQUdJLFdBQUssRUFBRU4sS0FBSyxDQUFDTyxLQUhqQjtBQUlJLGNBQVEsRUFBRVAsS0FBSyxDQUFDSTtBQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkosZUFRSSxxRUFBQyw4RUFBRDtBQUFBLDZCQUNJO0FBQUEsa0JBQUlKLEtBQUssQ0FBQ1E7QUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURKO0FBY0g7O0dBMUJRWixlO1VBRVVHLHFEOzs7S0FGVkgsZTs7QUFrRE1BLDhFQUFmIiwiZmlsZSI6Ii4vcGFnZXMvZXZlbnRzL1tldmVudERldGFpbFBhZ2VJZF0uanMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZVJvdXRlcn1mcm9tICduZXh0L3JvdXRlcic7XG4vLyBpbXBvcnQgeyBnZXRFdmVudEJ5SWQgfSBmcm9tICcuLi8uLi9kdW1teS1kYXRhJztcbmltcG9ydCB7IGdldEV2ZW50QnlJZCwgZ2V0QWxsRXZlbnRzIH0gZnJvbSAnLi4vLi4vYXBpLXV0aWwnO1xuaW1wb3J0IHsgRnJhZ21lbnQgfSBmcm9tICdyZWFjdCc7XG5cbmltcG9ydCBFdmVudFN1bW1hcnkgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9ldmVudC1kZXRhaWwvZXZlbnQtc3VtbWFyeSc7XG5pbXBvcnQgRXZlbnRMb2dpc3RpY3MgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9ldmVudC1kZXRhaWwvZXZlbnQtbG9naXN0aWNzJztcbmltcG9ydCBFdmVudENvbnRlbnQgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9ldmVudC1kZXRhaWwvZXZlbnQtY29udGVudCc7XG5mdW5jdGlvbiBFdmVudERldGFpbFBhZ2UocHJvcHMpe1xuICAgIC8v6rK966GcIOyEuOq3uOuovO2KuCDrjbDsnbTthLAg7LaU7LacXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gICAgY29uc3QgZXZlbnQgPSBwcm9wcy5zZWxlY3RlZEV2ZW50O1xuICAgIGNvbnNvbGUubG9nKGV2ZW50KTtcblxuICAgIC8v66eM7JW9IOyImOq4sOuhnCDqsr3roZzrpbwg7J6F66Cl7ZaI7J2EIOuVjCDrjbDsnbTthLDqsIAg7JeG64qUIOqyveyasFxuICAgIGlmKCFldmVudCl7XG4gICAgICAgIHJldHVybihcbiAgICAgICAgICAgIDxkaXY+U29ycnkgTm8gRGF0YTwvZGl2PlxuICAgICAgICApXG4gICAgfVxuICAgIHJldHVybihcbiAgICAgICAgPEZyYWdtZW50PlxuICAgICAgICAgICAgPEV2ZW50U3VtbWFyeSB0aXRsZT17ZXZlbnQudGl0bGV9Lz5cbiAgICAgICAgICAgIDxFdmVudExvZ2lzdGljcyBcbiAgICAgICAgICAgICAgICBkYXRlPXtldmVudC5kYXRlfVxuICAgICAgICAgICAgICAgIGFkZHJlc3M9e2V2ZW50LmxvY2F0aW9ufSBcbiAgICAgICAgICAgICAgICBpbWFnZT17ZXZlbnQuaW1hZ2V9IFxuICAgICAgICAgICAgICAgIGltYWdlQWx0PXtldmVudC50aXRsZX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8RXZlbnRDb250ZW50PlxuICAgICAgICAgICAgICAgIDxwPntldmVudC5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICA8L0V2ZW50Q29udGVudD5cbiAgICAgICAgPC9GcmFnbWVudD5cbiAgICApXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdGF0aWNQcm9wcyhjb250ZXh0KXtcbmNvbnN0IGV2ZW50SWQgPSBjb250ZXh0LnBhcmFtcy5ldmVudERldGFpbFBhZ2VJZDtcbmNvbnN0IGV2ZW50ID0gYXdhaXQgZ2V0RXZlbnRCeUlkKGV2ZW50SWQpO1xuLy8gY29uc3QgcmVzdWx0cyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZXZlbnQpKTtcblxuICAgIHJldHVybiB7XG4gICAgICAgIHByb3BzIDoge1xuICAgICAgICAgICAgc2VsZWN0ZWRFdmVudCA6IGV2ZW50ID8/IG51bGxcbiAgICAgICAgfVxuICAgIH07XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdGF0aWNQYXRocygpe1xuICAgIGNvbnN0IGV2ZW50cyA9IGdldEFsbEV2ZW50cygpO1xuICAgIGNvbnN0IHBhdGhzID0gYXdhaXQgZXZlbnRzLm1hcChldmVudCA9PiAoe1xuICAgICAgICBwYXJhbXMgOiB7ZXZlbnREZXRhaWxQYWdlSWQgOiBldmVudC5pZH1cbiAgICB9KSlcbiAgICByZXR1cm57XG4gICAgICAgIHBhdGhzIDogcGF0aHMsXG4gICAgICAgIGZhbGxiYWNrIDogZmFsc2VcbiAgICB9XG59XG5leHBvcnQgZGVmYXVsdCBFdmVudERldGFpbFBhZ2U7Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/events/[eventDetailPageId].js\n");

/***/ })

})