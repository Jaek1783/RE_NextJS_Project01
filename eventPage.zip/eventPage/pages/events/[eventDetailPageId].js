import {useRouter}from 'next/router';
import { getEventById } from '../../dummy-data';
import { Fragment } from 'react';

import EventSummary from '../../components/event-detail/event-summary';
import EventLogistics from '../../components/event-detail/event-logistics';
import EventContent from '../../components/event-detail/event-content';
function EventDetailPage(){
    //경로 세그먼트 데이터 추출
    const router = useRouter();
    const eventId = router.query.eventDetailPageId;
    const event = getEventById(eventId);

    //만약 수기로 경로를 입력했을 때 데이터가 없는 경우
    if(!event){
        return(
            <div>Sorry No Data</div>
        )
    }
    return(
        <Fragment>
            <EventSummary title={event.title}/>
            <EventLogistics 
                date={event.date}
                address={event.location} 
                image={event.image} 
                imageAlt={event.title}
            />
            <EventContent>
                <p>{event.description}</p>
            </EventContent>
        </Fragment>
    )
}

export default EventDetailPage;